import authReducer from './authReducer';
import chatReducer from './chatReducer';

export default {
    authReducer,
    chatReducer,
};
